function cumprimento(saudacao: string, nome: string): string {
  return `Olá ${saudacao} ${nome}, tudo bem? Tenha um bom dia!`;
}

console.log(cumprimento("Sr.", "Matheus"));
