function cumprimento(saudacao, nome) {
    return "Ol\u00E1 " + saudacao + " " + nome + ", tudo bem? Tenha um bom dia!";
}
console.log(cumprimento("Sr.", "Matheus"));
