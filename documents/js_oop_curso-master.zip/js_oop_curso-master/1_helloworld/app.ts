function helloWorld(nome: string) {
  return "Hello World " + nome;
}

let nome = "João";

console.log(helloWorld(nome));