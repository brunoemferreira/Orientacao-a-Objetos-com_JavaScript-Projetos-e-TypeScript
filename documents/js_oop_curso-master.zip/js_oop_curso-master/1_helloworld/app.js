function helloWorld(nome) {
    return "Hello World " + nome;
}
var nome = "João";
console.log(helloWorld(nome));
