var carro = "Ferrari";
var rodas = 4;
var temTetoSolar = true;
console.log(carro);
console.log(rodas);
console.log(temTetoSolar);
