let carro: string = "Ferrari";
let rodas: number = 4;
let temTetoSolar: boolean = true;

console.log(carro);
console.log(rodas);
console.log(temTetoSolar);