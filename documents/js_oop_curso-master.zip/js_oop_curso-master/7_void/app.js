function testandoVoid() {
    console.log("Executando uma função com tipo void");
}
testandoVoid();
