function testandoVoid(): void {
  console.log("Executando uma função com tipo void");
}

testandoVoid();

let teste: void;

teste = undefined;