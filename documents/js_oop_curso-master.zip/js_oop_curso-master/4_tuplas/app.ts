let aviao: [string, boolean, number, string];

aviao = ['Boeing', true, 5, '10 turbinas'];

console.log(aviao);