var aviao;
aviao = ['Boeing', true, 5, '10 turbinas'];
console.log(aviao);
