enum Barco {Motor = 2, Proa = 1, Popa = 1};

let numeroDeMotores = Barco.Motor;

console.log(numeroDeMotores);
console.log(Barco);