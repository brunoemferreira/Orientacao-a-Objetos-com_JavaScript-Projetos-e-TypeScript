var frutas = ['Banana', 'Maçã', 'Laranja'];
var numeros = [1, 2, 3, 4, 5];
console.log(frutas);
console.log(numeros);
var obj = {
    name: "Matheus",
    age: 29
};
console.log(obj);
console.log(obj.name);
