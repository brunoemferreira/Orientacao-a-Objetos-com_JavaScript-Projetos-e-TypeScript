var naoSabemos;
naoSabemos = 'teste';
naoSabemos = 3;
naoSabemos = true;
console.log(naoSabemos);
var listaIndefinada = [1, 'teste', true];
console.log(listaIndefinada);
