let naoSabemos: any;

naoSabemos = 'teste';
naoSabemos = 3;
naoSabemos = true;

console.log(naoSabemos);

let listaIndefinada: any[] = [1, 'teste', true];

console.log(listaIndefinada);